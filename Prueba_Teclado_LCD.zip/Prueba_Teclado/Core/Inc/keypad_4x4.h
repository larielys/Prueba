#ifndef INC_KEYPAD_4X4_H_
#define INC_KEYPAD_4X4_H_

char Keypad_Get_Char(void);

#endif
